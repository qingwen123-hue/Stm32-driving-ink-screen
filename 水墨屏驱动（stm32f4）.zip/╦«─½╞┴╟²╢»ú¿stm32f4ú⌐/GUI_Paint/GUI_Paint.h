#ifndef _PAINT_H
#define _PAINT_H
#include "sys.h"
#include "EDP_1in54.h"
#include "fonts.h"
typedef struct
{
	uint8_t *Image;
	int Height;
	int Width;
	
}PAINT;

extern PAINT Paint;

#define WHITE          0xFF
#define BLACK          0x00

typedef enum {
    DOT_PIXEL_1X1  = 1,		// 1 x 1
    DOT_PIXEL_2X2  , 		// 2 X 2
    DOT_PIXEL_3X3  ,		// 3 X 3
    DOT_PIXEL_4X4  ,		// 4 X 4
    DOT_PIXEL_5X5  , 		// 5 X 5
    DOT_PIXEL_6X6  , 		// 6 X 6
    DOT_PIXEL_7X7  , 		// 7 X 7
    DOT_PIXEL_8X8  , 		// 8 X 8
} DOT_PIXEL;

void Paint_CreatPaint(uint8_t * Image,int Height,int Width);
void Paint_SelectImage(uint8_t *Image);
void Paint_Clear(int Color);
void Paint_SetPix(int Xpoint,int Ypoint,int Color);
void Paint_DrawLine(int Xstart,int Ystart,int Xend,int Yend,int Color);
void Paint_DrawRectangle(int Xstart,int Ystart,int Xend,int Yend,int Color);
void Paint_DrawFillRectangle(int Xstart,int Ystart,int Xend,int Yend,int Color);
void Paint_DrawCircle(int Xcenter,int Ycenter,int Radius,int Color);
void Paint_DrawFillCircle(int Xcenter,int Ycenter,int Radius,int Color);

void Paint_DrawChar(int X,int Y,char ascii_char,sFONT *font,int Color);
void Paint_DrawString(int X,int Y,char* string,sFONT *font,int Color);
void Paint_DrawNum(int X,int Y,int Num,sFONT *font,int Color);
void Paint_DrawNumDecimals(int X, int Y, double Nummber,sFONT* font, int Digit,int Color);
void Paint_DrawCNString(int X,int Y,char* string,cFONT* font,int Color);


#endif

