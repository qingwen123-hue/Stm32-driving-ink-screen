#ifndef _IMAGE_H
#define _IMAGE_H
#include "sys.h"
extern uint8_t gImage_1in54[5000];
extern uint8_t gImage_test[5000];
#endif
