#ifndef _EDP_H
#define _EDP_H
#include "sys.h"
#include "stm32f4xx_hal.h"
#include "spi.h"

#define EDP_RST  RST_GPIO_Port,RST_Pin
#define EDP_DC   DC_GPIO_Port,DC_Pin
#define EDP_BUSY BUSY_GPIO_Port,BUSY_Pin
#define EDP_CS   SPI_CS_GPIO_Port,SPI_CS_Pin

#define EDP_GPIO_Write(_pin,_value) HAL_GPIO_WritePin(_pin,_value == 0 ? GPIO_PIN_RESET:GPIO_PIN_SET)
#define EDP_GPIO_Read(_pin) HAL_GPIO_ReadPin(_pin)

#define EDP_WIDTH       200
#define EDP_HEIGHT      200

void EDP_SendData(uint8_t Reg);
void EDP_SendCommand(uint8_t Reg);
void EDP_SPI_WriteByte(uint8_t Reg);
void EDP_ReadBusy(void);
void EDP_Reset(void);
void EDP_SetWindows(uint16_t Xstart,uint16_t Ystart,uint16_t Xend,uint16_t Yend);
void EDP_SetCursor(uint16_t Xstart,uint16_t Ystart);

void EDP_Init(void);
void EDP_TurnOnDisplay(void);
void EDP_Init_Partial(void);
void EDP_TurnOnDisplayPart(void);
void EDP_Clear(void);
void EDP_Test(void);
void EDP_Sleep(void);
void EDP_Display(uint8_t *Image);
void EDP_DisplayPartBaseImage(uint8_t *Image);
void EDP_DisplayPart(uint8_t *Image);

void EDP_Module_Init(void);
void EDP_Module_Exit(void);
#endif
