#ifndef _SPI_H
#define _SPI_H
#include "sys.h"
#include "stm32f4xx_hal.h"

#define RST_Pin GPIO_PIN_12
#define RST_GPIO_Port GPIOB
#define DC_Pin GPIO_PIN_13
#define DC_GPIO_Port GPIOB
#define BUSY_Pin GPIO_PIN_14
#define BUSY_GPIO_Port GPIOB
#define SPI_CS_Pin GPIO_PIN_15
#define SPI_CS_GPIO_Port GPIOB

extern SPI_HandleTypeDef SPI1_Handler;  //SPI���

void SPI1_Init(void);
#endif
