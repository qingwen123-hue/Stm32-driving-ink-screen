#include "sys.h"
#include "delay.h"
#include "usart.h"
#include "led.h"
#include "EDP_1in54.h"
#include "Image.h"
#include "GUI_Paint.h"
#include "fonts.h"

int main(void)
{ 
    HAL_Init();                    	//��ʼ��HAL��    
    Stm32_Clock_Init(336,8,2,7);  	//����ʱ��,168Mhz
	delay_init(168);               	//��ʼ����ʱ����
	LED_Init();						//��ʼ��LED	
	
	SPI1_Init();
	EDP_Module_Init();
	EDP_Init();
	EDP_Clear();
	
	Paint_CreatPaint(gImage_test,EDP_HEIGHT,EDP_WIDTH);
	EDP_Display(gImage_test);
	HAL_Delay(500);
	
	
	
	Paint_Clear(BLACK);
	EDP_Display(gImage_test);
	HAL_Delay(500);
	

	Paint_DrawRectangle(20,20,80,80,WHITE);
	Paint_DrawFillRectangle(100,100,180,180,WHITE);
	EDP_Display(gImage_test);
	HAL_Delay(500);
	
	Paint_DrawCircle(140,40,30,WHITE);
	Paint_DrawFillCircle(50,130,40,WHITE);
	EDP_Display(gImage_test);
	HAL_Delay(500);
	
	Paint_Clear(BLACK);
	EDP_Display(gImage_test);
	HAL_Delay(500);
	
	EDP_Init_Partial();
	EDP_DisplayPartBaseImage(gImage_test);
	
	
	Paint_DrawChar(50,50,'D',&Font8,WHITE);
	EDP_DisplayPart(gImage_test);
	HAL_Delay(100);
	Paint_DrawChar(70,50,'s',&Font12,WHITE);
	EDP_DisplayPart(gImage_test);
	HAL_Delay(100);
	Paint_DrawChar(90,50,'d',&Font16,WHITE);
	EDP_DisplayPart(gImage_test);
	HAL_Delay(100);
	Paint_DrawChar(110,50,'M',&Font20,WHITE);
	EDP_DisplayPart(gImage_test);
	HAL_Delay(100);
	Paint_DrawChar(130,50,'M',&Font24,WHITE);
	EDP_DisplayPart(gImage_test);
	HAL_Delay(100);
	Paint_DrawString(50,100,"SDFsys",&Font16,WHITE);
	EDP_DisplayPart(gImage_test);
	HAL_Delay(100);
	Paint_DrawNum(50,130,3456,&Font16,WHITE);
	EDP_DisplayPart(gImage_test);
	HAL_Delay(100);
	Paint_DrawNumDecimals(50,150,2323.112,&Font16,3,WHITE);
	EDP_DisplayPart(gImage_test);
	HAL_Delay(100);
	Paint_DrawCNString(0,0,"���Ĳ���",&Font12CN,WHITE);
	EDP_DisplayPart(gImage_test);
	HAL_Delay(100);
	HAL_Delay(500);
	

	while(1)
	{
		HAL_GPIO_WritePin(GPIOF,GPIO_PIN_9,GPIO_PIN_SET);
		HAL_Delay(1000);
		HAL_GPIO_WritePin(GPIOF,GPIO_PIN_9,GPIO_PIN_RESET);
		HAL_Delay(1000);
	}
}

